Titanic Predictor - Console ML App

How to Run:
1. Make sure Python is installed.
2. Open command prompt and run:
   pip install -r requirements.txt
3. Open titanic_predictor.py in IDLE.
4. Press F5 to run.

This app predicts survival chances on the Titanic based on user input.
