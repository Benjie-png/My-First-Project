import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier

# Load Titanic dataset
data = sns.load_dataset('titanic')
data.dropna(subset=['age', 'sex', 'pclass', 'survived'], inplace=True)

# Encode categorical variables
data['sex'] = data['sex'].map({'male': 0, 'female': 1})

# Features and target
X = data[['age', 'sex', 'pclass']]
y = data['survived']

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Ask user for input
print("\n🚢 Titanic Survival Predictor")
age = float(input("Enter age: "))
sex_input = input("Enter sex (male/female): ").strip().lower()
sex = 0 if sex_input == 'male' else 1
pclass = int(input("Enter passenger class (1, 2, or 3): "))

# Predict
user_input = pd.DataFrame([[age, sex, pclass]], columns=['age', 'sex', 'pclass'])
prediction = model.predict(user_input)[0]

# Show result
if prediction == 1:
    print("\n✅ Prediction: The passenger would have SURVIVED.")
else:
    print("\n❌ Prediction: The passenger would NOT have survived.")
